package com.cg.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTestKarateApplicationTests {

	@Test
	void contextLoads() {
	}

}
